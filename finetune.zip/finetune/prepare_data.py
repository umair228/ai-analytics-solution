"""
Build the DIS domain-adaptation fine-tuning dataset (Phase 6).

Generates chat-format SFT examples that teach a Qwen2.5 model the EGPC + petroleum-
QC + ASTM/ISO domain, grounded in REAL data already in the platform:

  * Glossary  -> definition Q&A (finetune/glossary.json)
  * EGPC facts-> Q&A from the seeded EGPC cached datasets (products, analyses,
                 sulphur, spec compliance, off-spec, instruments)
  * Standards -> grounded Q&A from the indexed ASTM/ISO corpus (docsearch.eval_astm
                 questions + retrieved passages)
  * Tool sense-> a few exemplars teaching which analysis answers which question

Output: finetune/data/domain_sft.jsonl  (one JSON object per line:
{"messages":[{"role":"system",...},{"role":"user",...},{"role":"assistant",...}]})

This RUNS locally (no GPU) — it only reads data and writes JSONL. Review/curate the
output, then train with finetune/train_qlora.py on the GPU box.

    .venv/bin/python finetune/prepare_data.py
"""
import json
import os
import sys
from pathlib import Path

import django

# This script lives in finetune/ — put the project root on the path so the
# Django `config` settings package is importable.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings.dev")
django.setup()

from datasets.models import Dataset  # noqa: E402

HERE = Path(__file__).resolve().parent
OUT = HERE / "data" / "domain_sft.jsonl"

SYS = (
    "You are the DIS analytics assistant for the EGPC petroleum-quality "
    "laboratory. You understand LabWare LIMS data (samples, tests, results, "
    "specifications), petroleum-QC analyses, and ASTM/ISO standards. Answer "
    "accurately and concisely, grounded in the lab's data and standards."
)


def ex(user, assistant):
    return {"messages": [
        {"role": "system", "content": SYS},
        {"role": "user", "content": user},
        {"role": "assistant", "content": assistant},
    ]}


def _ds(name):
    d = Dataset.objects.filter(name=name).first()
    if not d or not d.cached_rows:
        return None, None
    cols = [str(c) for c in (d.cached_columns or [])]
    return cols, d.cached_rows


def _col(cols, name):
    return cols.index(name) if cols and name in cols else -1


def glossary_examples():
    out = []
    data = json.loads((HERE / "glossary.json").read_text())
    for t in data["terms"]:
        out.append(ex(f"What is {t['term']} in petroleum quality testing?", t["definition"]))
        out.append(ex(f"Define {t['term']}.", t["definition"]))
    return out


def egpc_examples():
    out = []

    cols, rows = _ds("EGPC Samples by Product")
    if rows:
        ip, isam = _col(cols, "product"), _col(cols, "samples")
        top = sorted(rows, key=lambda r: -(r[isam] or 0))[:8]
        names = ", ".join(str(r[ip]) for r in top[:8])
        out.append(ex("Which products does the EGPC laboratory test most?",
                      f"The most-tested EGPC products by sample volume are: {names}."))
        for r in top[:6]:
            out.append(ex(f"How many samples has the EGPC lab logged for {r[ip]}?",
                          f"The EGPC lab has logged {r[isam]:,} samples for {r[ip]}."))

    cols, rows = _ds("EGPC Test Volume by Analysis")
    if rows:
        ia, ipct = _col(cols, "analysis"), _col(cols, "in_spec_pct")
        top = rows[:8]
        out.append(ex("What are the highest-volume analyses run in the EGPC lab?",
                      "The highest-volume EGPC analyses include: "
                      + ", ".join(str(r[ia]) for r in top[:8]) + "."))
        for r in top[:5]:
            if ipct >= 0 and r[ipct] is not None:
                out.append(ex(f"What is the in-spec rate for the {r[ia]} analysis?",
                              f"The {r[ia]} analysis has an in-spec rate of {r[ipct]}%."))

    cols, rows = _ds("EGPC Spec Compliance by Product")
    if rows:
        ip, ipct = _col(cols, "product"), _col(cols, "in_spec_pct")
        worst = sorted([r for r in rows if r[ipct] is not None], key=lambda r: r[ipct])[:5]
        if worst:
            out.append(ex("Which EGPC products have the lowest spec-compliance rate?",
                          "Lowest first-pass spec compliance: "
                          + "; ".join(f"{r[ip]} ({r[ipct]}%)" for r in worst) + "."))

    cols, rows = _ds("EGPC Sulphur by Product")
    if rows:
        ip, iavg, iu = _col(cols, "product"), _col(cols, "avg_sulphur"), _col(cols, "units")
        for r in rows[:8]:
            u = r[iu] if iu >= 0 and r[iu] else ""
            out.append(ex(f"What is the average sulphur content for {r[ip]} at EGPC?",
                          f"The average total-sulfur result for {r[ip]} is {r[iavg]} {u}."))

    cols, rows = _ds("EGPC Off-Spec by Operator")
    if rows:
        io, ipct = _col(cols, "operator"), _col(cols, "off_spec_pct")
        worst = sorted([r for r in rows if r[ipct] is not None], key=lambda r: -r[ipct])[:5]
        if worst:
            out.append(ex("Which analysts have the highest out-of-spec result rate at EGPC?",
                          "Highest off-spec rates: "
                          + "; ".join(f"{r[io]} ({r[ipct]}%)" for r in worst)
                          + ". This warrants review of method/technique, not blame."))

    cols, rows = _ds("EGPC Instruments & Calibration")
    if rows:
        out.append(ex("How many instruments are registered in the EGPC LIMS?",
                      f"There are {len(rows)} instruments registered, each with "
                      "calibration and preventive-maintenance dates tracked."))
    return out


def _egpc_conn():
    import pyodbc
    from decouple import config
    cs = (f"DRIVER={{{config('DB_DRIVER', default='ODBC Driver 18 for SQL Server')}}};"
          f"SERVER={config('DB_HOST', default='127.0.0.1')},{config('DB_PORT', default=1433)};"
          f"DATABASE={config('DB_NAME', default='EGPC_DEV')};"
          f"UID={config('DB_USER', default='SA')};PWD={config('DB_PASSWORD', default='')};"
          f"TrustServerCertificate=yes;Encrypt=no")
    return pyodbc.connect(cs, timeout=15)


def _r(x, p=4):
    try:
        return round(float(x), p)
    except (TypeError, ValueError):
        return None


def live_egpc_examples():
    """The rich source — grounded Q&A queried straight from the live EGPC_DEV DB:
    per-product analyses, per-analysis units/range/in-spec, numeric spec limits,
    sulphur, out-of-spec leaders, and operations facts."""
    out = []
    try:
        cn = _egpc_conn()
    except Exception as exc:  # noqa: BLE001
        print(f"  live EGPC DB unavailable ({exc}) — using cached datasets only.")
        return out
    c = cn.cursor()

    # 1. Products + sample volumes
    products = c.execute(
        "SELECT TOP 30 PRODUCT, COUNT(*) n FROM dbo.SAMPLE "
        "WHERE PRODUCT IS NOT NULL GROUP BY PRODUCT ORDER BY n DESC").fetchall()
    for p, n in products:
        out.append(ex(f"How many samples has the EGPC lab tested for {p}?",
                      f"The EGPC laboratory has logged {n:,} samples for {p}."))
    if products:
        names = ", ".join(p for p, _ in products[:12])
        out.append(ex("What products does the EGPC laboratory test most?",
                      f"The most-tested EGPC products by sample volume are: {names}."))

    # 2. Per-product analyses
    for p, _ in products[:20]:
        ans = c.execute(
            "SELECT TOP 8 r.ANALYSIS, COUNT(*) n FROM dbo.RESULT r "
            "JOIN dbo.SAMPLE s ON r.SAMPLE_NUMBER=s.SAMPLE_NUMBER "
            "WHERE s.PRODUCT=? GROUP BY r.ANALYSIS ORDER BY n DESC", p).fetchall()
        if ans:
            out.append(ex(f"What analyses does the EGPC lab run on {p}?",
                          f"On {p}, EGPC most commonly runs these analyses: "
                          + ", ".join(a for a, _ in ans) + "."))

    # 3. Per-analysis: units, typical range, in-spec rate
    analyses = c.execute(
        "SELECT TOP 30 ANALYSIS, COUNT(*) n FROM dbo.RESULT "
        "WHERE NUMERIC_ENTRY IS NOT NULL GROUP BY ANALYSIS ORDER BY n DESC").fetchall()
    for a, _ in analyses:
        meta = c.execute(
            "SELECT TOP 1 NAME, UNITS FROM dbo.RESULT WHERE ANALYSIS=? "
            "AND UNITS IS NOT NULL AND UNITS<>''", a).fetchone()
        st = c.execute(
            "SELECT AVG(v), MIN(v), MAX(v), "
            "100.0*SUM(CASE WHEN insp='T' THEN 1 ELSE 0 END)/COUNT(*) FROM "
            "(SELECT TRY_CONVERT(float,NUMERIC_ENTRY) v, IN_SPEC insp FROM dbo.RESULT "
            " WHERE ANALYSIS=? AND NUMERIC_ENTRY IS NOT NULL) t WHERE v IS NOT NULL", a).fetchone()
        if not st or st[0] is None:
            continue
        name = meta[0] if meta else a
        units = (meta[1] if meta else "") or ""
        out.append(ex(
            f"What does the {a} analysis measure at EGPC, and what is its typical range?",
            f"{a} ({name}) is reported in {units}. Typical EGPC values average "
            f"{_r(st[0])} (range {_r(st[1])}–{_r(st[2])}), with an in-spec rate of "
            f"{_r(st[3],1)}%."))

    # 4. Numeric specification limits (the MOM 'numerical specifications')
    specs = c.execute(
        "SELECT TOP 50 PRODUCT, ANALYSIS, COMPONENT, "
        "TRY_CONVERT(float,LSL), TRY_CONVERT(float,USL), "
        "TRY_CONVERT(float,MIN_VALUE), TRY_CONVERT(float,MAX_VALUE), UNITS "
        "FROM dbo.PRODUCT_SPEC WHERE COALESCE(TRY_CONVERT(float,LSL),0)<>0 "
        "OR COALESCE(TRY_CONVERT(float,USL),0)<>0 "
        "OR COALESCE(TRY_CONVERT(float,MIN_VALUE),0)<>0 "
        "OR COALESCE(TRY_CONVERT(float,MAX_VALUE),0)<>0").fetchall()
    seen_spec = set()
    for p, a, comp, lsl, usl, mn, mx, u in specs:
        lo = lsl if (lsl not in (None, 0)) else mn
        hi = usl if (usl not in (None, 0)) else mx
        key = (p, comp)
        if key in seen_spec or (lo in (None, 0) and hi in (None, 0)):
            continue
        seen_spec.add(key)
        u = u or ""
        rng = (f"{_r(lo)}–{_r(hi)} {u}" if (lo not in (None, 0) and hi not in (None, 0))
               else f"max {_r(hi)} {u}" if hi not in (None, 0) else f"min {_r(lo)} {u}")
        out.append(ex(f"What is the EGPC specification limit for {comp} on {p}?",
                      f"The EGPC specification for {comp} ({a}) on {p} is {rng}."))

    # 5. Sulphur by product
    sulf = c.execute(
        "SELECT TOP 17 s.PRODUCT, AVG(TRY_CONVERT(float,r.NUMERIC_ENTRY)) avg_s, "
        "MAX(TRY_CONVERT(float,r.NUMERIC_ENTRY)) max_s, MAX(r.UNITS) u "
        "FROM dbo.RESULT r JOIN dbo.SAMPLE s ON r.SAMPLE_NUMBER=s.SAMPLE_NUMBER "
        "WHERE (r.ANALYSIS LIKE 'SULFUR%' OR r.NAME LIKE '%Sulfur%') "
        "AND r.NUMERIC_ENTRY IS NOT NULL AND s.PRODUCT IS NOT NULL "
        "GROUP BY s.PRODUCT ORDER BY avg_s DESC").fetchall()
    for p, avg_s, max_s, u in sulf:
        out.append(ex(f"What is the average sulphur content for {p} at EGPC?",
                      f"For {p}, the average total-sulfur result is {_r(avg_s)} {u or ''} "
                      f"(maximum observed {_r(max_s)})."))

    # 6. Worst out-of-spec products
    osp = c.execute(
        "SELECT TOP 6 s.PRODUCT, COUNT(*) n, "
        "100.0*SUM(CASE WHEN r.IN_SPEC='F' THEN 1 ELSE 0 END)/COUNT(*) offrate "
        "FROM dbo.RESULT r JOIN dbo.SAMPLE s ON r.SAMPLE_NUMBER=s.SAMPLE_NUMBER "
        "WHERE s.PRODUCT IS NOT NULL GROUP BY s.PRODUCT HAVING COUNT(*)>=50 "
        "ORDER BY offrate DESC").fetchall()
    if osp:
        lead = "; ".join(f"{p} ({_r(offrate,1)}% off-spec, n={n})" for p, n, offrate in osp[:5])
        out.append(ex("Which EGPC products have the worst out-of-spec rate?",
                      f"By individual result, the highest off-spec rates are: {lead}. "
                      "These warrant root-cause investigation."))

    # 7. Operations facts
    row = c.execute("SELECT COUNT(*), MIN(LOGIN_DATE), MAX(LOGIN_DATE) FROM dbo.SAMPLE").fetchone()
    if row:
        out.append(ex("How much sample data does the EGPC LIMS hold?",
                      f"The EGPC LIMS holds {row[0]:,} samples spanning "
                      f"{str(row[1])[:10]} to {str(row[2])[:10]}."))
    tat = c.execute(
        "SELECT AVG(CAST(DATEDIFF(hour,LOGIN_DATE,DATE_COMPLETED) AS float)) FROM dbo.SAMPLE "
        "WHERE DATE_COMPLETED IS NOT NULL AND DATEDIFF(hour,LOGIN_DATE,DATE_COMPLETED) BETWEEN 0 AND 8760").fetchone()
    if tat and tat[0] is not None:
        out.append(ex("What is the average sample turnaround time at EGPC?",
                      f"The average turnaround time (login to completion) is "
                      f"{_r(tat[0],1)} hours across completed EGPC samples."))
    cn.close()
    return out


def standards_examples():
    out = []
    try:
        from docsearch.index_store import get_index
        idx = get_index()
        if not idx.ready or idx.df.empty:
            return out
        items = json.loads((HERE.parent / "docsearch" / "eval_astm.json").read_text())["items"]
        for it in items:
            rows, _ = idx.retrieve(it["question"], top_k=3)
            if not rows:
                continue
            r0 = rows[0]
            get = r0.get if hasattr(r0, "get") else (lambda k, d=None: r0[k])
            passage = " ".join((get("chunk_text", "") or "").split())[:480]
            src = get("doc_id", "") or "the standards"
            if len(passage) < 60:
                continue
            out.append(ex(it["question"], f"{passage} (Source: {src})"))
    except Exception as exc:  # noqa: BLE001
        print(f"  standards skipped: {exc}")
    return out


def tool_sense_examples():
    return [
        ex("How would you find why results are failing spec?",
           "Run a root-cause (driver) analysis on the out-of-spec flag (IN_SPEC='F') "
           "against factors like product, analysis and the operator who entered the "
           "result (ENTERED_BY) — it ranks each factor's lift over the base off-spec rate."),
        ex("How do you assess whether a process meets its sulphur specification?",
           "Compute process capability (Cp/Cpk) on the sulphur results versus the "
           "product's LSL/USL from PRODUCT_SPEC, and plot an individuals control chart; "
           "Cpk ≥ 1.33 indicates a capable process."),
        ex("How would you forecast next quarter's sample workload?",
           "Resample the SAMPLE login dates into a monthly time series and project it "
           "forward (trend + smoothing), optionally per process unit or product."),
    ]


def main():
    OUT.parent.mkdir(parents=True, exist_ok=True)
    groups = {
        "glossary": glossary_examples(),
        "egpc_live": live_egpc_examples(),     # rich, from the live DB
        "egpc_cached": egpc_examples(),        # curated summaries (supplement)
        "standards": standards_examples(),
        "tool_sense": tool_sense_examples(),
    }
    seen, examples = set(), []
    for items in groups.values():
        for e in items:
            q = e["messages"][1]["content"].strip().lower()
            if q in seen:
                continue
            seen.add(q)
            examples.append(e)

    with OUT.open("w", encoding="utf-8") as f:
        for e in examples:
            f.write(json.dumps(e, ensure_ascii=False) + "\n")

    print(f"✓ wrote {len(examples)} SFT examples (deduped) -> {OUT}")
    print("\nbreakdown (pre-dedup):")
    for name, items in groups.items():
        print(f"  {name:12s}: {len(items)}")
    print("\nsample examples:")
    for e in (examples[0], examples[len(examples) // 2], examples[-1]):
        print(f"  Q: {e['messages'][1]['content']}")
        print(f"  A: {e['messages'][2]['content'][:130]}…\n")


if __name__ == "__main__":
    main()
